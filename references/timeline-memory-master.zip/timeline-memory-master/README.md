# Timeline Memory

A SillyTavern extension for creating a timeline of summarized chapters from your chat sessions, with intelligent context retrieval and lorebook management capabilities.

## Features

- **Chapter Timeline**: Summarize chapters and track them in a linear timeline accessible via macros
- **Arc Analyzer**: AI-powered detection of natural chapter endpoints in your chat
- **Auto-Summarize**: Automatic chapter creation when message threshold is reached
- **Timeline Fill**: Smart context retrieval that queries relevant chapters based on current conversation
- **Agentic Timeline Fill**: Advanced tool-based retrieval where an AI agent dynamically queries chapters and lorebook
- **Loading Screen**: Immersive fullscreen loading experience with ambient music, backgrounds, and fun facts
- **Mini-Games**: Play Snake, Breakout, or Tetris while waiting for long operations
- **Inject at Depth**: Automatic timeline injection into AI context without prompt editing
- **Lore Management Mode**: Autonomous AI-driven lorebook editing based on story events
- **Customizable Presets**: Save and share configurations for all workflow types
- **AI Tool Calls**: Enable the AI to query specific chapters directly via function calls
- **Chat Cleanup Tools**: Built-in commands to remove reasoning traces and tool call artifacts

## Installation

Install like any other SillyTavern extension using the GitHub link:
```
https://github.com/unkarelian/timeline-memory
```

## Requirements

- SillyTavern version 1.13.0 or higher
- Connection Manager extension (for profile selection)

## Quick Start

1. **Create Connection Profiles**: Set up profiles in Connection Manager for your AI providers
2. **Enable Inject at Depth**: Turn on automatic timeline injection (recommended for most users)
3. **Create Chapters**: Use Arc Analyzer or manual chapter buttons to create chapter summaries
4. **Use Timeline Fill**: Click the quick buttons to retrieve relevant context before sending messages

## Core Concepts

### Chapters

A chapter represents a segment of your chat with an AI-generated summary. Chapters are defined by their endpoints - when you "end a chapter," the extension summarizes all messages from the previous chapter end (or chat start) to that point.

### Timeline

The timeline is a chronological list of all your chapter summaries, stored in the chat metadata. It's accessible via the `{{timeline}}` macro and can be automatically injected into the AI's context.

### Connection Profiles

Timeline Memory uses SillyTavern's Connection Manager profiles for all AI API calls. Different profiles can be assigned to different tasks (summarization, queries, arc analysis, etc.).

## Features Guide

### Chapter Management

#### Arc Analyzer (Recommended)

The Arc Analyzer scans your chat and suggests natural chapter endpoints based on story beats.

1. Select an **Arc Analyzer Profile** in settings (or use default)
2. Click **"Analyze Arcs"** button
3. Review the suggested chapter breaks in the popup
4. Click on any arc to create a chapter ending at that point

The AI will summarize everything from the start (or last chapter) to the selected point.

#### Manual Chapter Creation

Click the **Stop button** on any message to manually end a chapter:

1. Hover over any message in the chat
2. Click the stop button that appears
3. The AI summarizes all messages from the previous chapter end to that message

The button only appears if "End Chapter" is enabled in Message Buttons settings.

#### Auto-Summarize

Auto-Summarize automatically creates chapters when your chat reaches a certain length, without manual intervention.

**How it works:**
1. Set a **Threshold (N)** - the number of messages that must accumulate before triggering
2. Set a **Buffer (X)** - recent messages to exclude from endpoint selection
3. When messages since last chapter >= N + X, the AI selects an optimal endpoint
4. A chapter is automatically created at that point

**To enable:**
1. Check "Enable Auto-Summarize"
2. Select an **Auto-Summarize Profile** (must support function calls)
3. Adjust Threshold and Buffer as needed (defaults: N=50, X=10)

**Example:** With N=50 and X=10, when 60 messages accumulate since the last chapter, the AI will analyze messages 1-50 and select the best chapter endpoint.

#### Viewing & Editing Summaries

Chapter summaries appear in the **Summaries** section of the settings panel:

- **Edit** summaries by clicking directly on the text
- **Expand** using the expand button for a larger editor
- **Save** changes with the Save button

Good summaries lead to better recall - focus on key plot points, character changes, and important details.

### Timeline Fill (Smart Retrieval)

Timeline Fill automatically queries your chapter history to gather relevant context for the current conversation.

**How it works:**
1. The AI reads your current chat and chapter summaries
2. It identifies what past information is relevant
3. It queries the appropriate chapters and retrieves details
4. Results are stored in `{{timelineResponses}}` and injected into context

**Quick Buttons** (in the bottom bar near the send button):
- **Chat bubble** - Retrieve and Send: Retrieves timeline context, then sends your message
- **Recycle wheel** - Retrieve and Swipe: Retrieves timeline context, then regenerates the last response

### Agentic Timeline Fill (Advanced)

Agentic Timeline Fill is an advanced alternate mode where an AI agent dynamically retrieves context using tools - similar to Lore Management Mode.

**How it differs from static Timeline Fill:**
- **Static**: AI proposes queries in one batch, all executed automatically
- **Agentic**: AI actively uses tools to query chapters, can adapt based on results

**Available tools for the agent:**
- `query_timeline_chapter` - Query a single chapter
- `query_timeline_chapters` - Query a range of chapters (respects the chapter limit setting)
- `list_lorebook_entries` - Access the character's lorebook/world info
- `end_information_retrieval` - Signal completion with final summary

**Requirements:**
- A model that supports function/tool calls (GLM 4.6, Claude, Grok 4 Fast, etc.)
- An Agentic Timeline Fill profile configured

**To use:**
1. Create an Agentic Timeline Fill Profile using a capable model with tool support
2. Select the profile in the Agentic Timeline Fill section
3. Enable "Agentic Timeline Fill Mode"
4. Use the quick buttons or click "Run Agentic Timeline Fill"

The agent ends its session by calling `end_information_retrieval` with the crucial information it found, which is saved to `{{timelineResponses}}`.

**Note:** The "Max Timeline Fill Queries" limit does NOT apply to agentic mode - the agent decides when to stop. However, the "Max Chapters per Query" limit still applies to `query_timeline_chapters`.

**Recommended preset:** [Retrieval Management](https://raw.githubusercontent.com/unkarelian/timeline-extension-prompts/refs/heads/master/Retrieval%20Management.json) (Import via SillyTavern's Chat Completion settings)

### Inject at Depth

Inject at Depth automatically adds your timeline to the AI's context without manual prompt editing.

**To enable:**
1. Check "Enable Timeline Injection"
2. Set **Injection Depth** (0 = at the end, higher = further back in history)
3. Choose **Injection Role** (System recommended)

The default prompt template includes:
- `{{timeline}}` - Your chapter summaries
- `{{timelineResponses}}` - Retrieved context from Timeline Fill
- `{{lastMessageId}}` and `{{firstIncludedMessageId}}` - Position info

**Depth explained:**
- Depth 0: Appears after all messages (closest to AI response)
- Depth 1: Appears before the last message
- Higher depths: Pushes the injection further back

### Presets

Presets let you save and switch between different prompt configurations.

**Preset types:**
- **Summarization**: Prompts for creating chapter summaries
- **Query**: Prompts for answering chapter questions
- **Timeline Fill**: Prompts for context retrieval
- **Arc Analyzer**: Prompts for detecting story arcs

**Managing presets:**
- **Save**: Create a new preset from current settings
- **Update**: Overwrite the selected preset
- **Delete**: Remove the selected preset
- **Export/Import**: Share presets as JSON files
- **Export All / Import All**: Backup/restore your entire configuration

### Lore Management Mode

Lore Management Mode lets the AI automatically update your character's lorebook based on story events.

**What it does:**
The AI reads your story, identifies important lore (characters, locations, events, relationships), and creates/updates lorebook entries automatically.

**Requirements:**
- A character with an assigned World Info/Lorebook
- A capable AI model that supports function/tool calls
- A properly configured Lore Management profile

**To use:**
1. Create a Lore Management Profile using a powerful model with tool support
2. Select the profile in the Lore Management section
3. Ensure your character has a lorebook assigned
4. Enable "Lore Management Mode"
5. Click "Run Lore Management"
6. The AI analyzes your story and edits the lorebook
7. When done, it signals completion automatically

**The AI can:**
- List existing lorebook entries
- Create new entries with keywords
- Update existing entries with new information
- Set entries as "constant" (always active) or keyword-triggered
- Delete entries when appropriate

### Loading Screen

During Timeline Fill, Agentic Timeline Fill, and Lore Management operations, a fullscreen loading screen appears with:

- **Ambient backgrounds and music** - Customizable atmosphere while you wait
- **Rotating fun facts** - Random trivia to keep you entertained
- **Abort button** - Cancel the operation at any time

**Customizing the loading screen:**

Add your own backgrounds and music by placing numbered files in the assets folder:
- `assets/backgrounds/1.png`, `2.jpg`, `3.png`, etc.
- `assets/music/1.mp3`, `2.mp3`, `3.ogg`, etc.

Files are automatically paired by number. See `assets/README.md` for details.

### Mini-Games

While waiting for long operations, you can play retro-style mini-games:

- **Snake** - Classic snake game with arrow keys or WASD
- **Breakout** - Brick-breaking paddle game
- **Tetris** - The timeless puzzle game

Games appear in a sidebar during loading. Add `assets/music/game.mp3` for game music.

### AI Tool Calls

When "Enable Tool/Function Calls" is checked, the AI can query chapters directly:
- `query_timeline_chapter`: Query a single chapter
- `query_timeline_chapters`: Query a range of chapters

This allows the AI to access the full content of any summarized chapter and answer questions about specific events.

## Macros

The extension provides the following macros for use in prompts:

| Macro | Description |
|-------|-------------|
| `{{timeline}}` | JSON-formatted timeline of all chapter summaries with chapter IDs and message ranges |
| `{{chapter}}` | All chapter contents with headers in order |
| `{{chapterSummary}}` | All chapter summaries with headers in order |
| `{{chapterHistory}}` | Visible chat history as JSON array of `{ id, name, role, text }` |
| `{{timelineResponses}}` | Latest timeline fill query results as JSON array |
| `{{lastMessageId}}` | The ID of the most recent message in the chat |
| `{{firstIncludedMessageId}}` | The ID of the first message in the current chapter |

## Slash Commands

### Chapter Management

| Command | Description |
|---------|-------------|
| `/chapter-end {id}` | End the chapter at a message (defaults to most recent). Options: `profile` |
| `/timeline-undo {id}` | Remove a chapter end marker and its timeline entry |
| `/timeline-remove {n}` | Force remove a chapter by number (useful if marker cleanup failed) |
| `/resummarize chapter={n}` | Regenerate summary for an existing chapter. Options: `profile`, `quiet` |

### Queries

| Command | Description |
|---------|-------------|
| `/timeline-query chapter={n} {question}` | Query a specific chapter with a question |
| `/timeline-query-chapters start={n} end={m} {question}` | Query a range of chapters |
| `/chapter-summary {n}` | Get the summary of a specific chapter |

### Timeline Fill

| Command | Description |
|---------|-------------|
| `/timeline-fill` | Generate and execute timeline queries, store results in `{{timelineResponses}}`. Options: `profile`, `await` |
| `/timeline-fill-status` | Preview stored timeline fill results |

### Analysis & Management

| Command | Description |
|---------|-------------|
| `/arc-analyze` | Analyze the chat for arc endpoints and show popup. Options: `profile` |
| `/lore-manage` | Start a lore management session |

### Chat Cleanup

| Command | Description |
|---------|-------------|
| `/remove-reasoning {range}` | Remove reasoning/thinking blocks from messages (e.g., `5` or `1-10`) |
| `/remove-tool-calls` | Remove all tool call messages and their invoking prompts |

### Utility

| Command | Description |
|---------|-------------|
| `/timeline-migrate` | Migrate old timeline entries to current format |

## Configuration

### General Settings

- **Enable Tool/Function Calls**: Allow the AI to query chapters via function calls
- **Start Tutorial**: Launch the interactive tutorial
- **Export All / Import All**: Backup and restore your entire configuration

### API Connection Profiles

- **Summarization Profile**: For chapter summarization
- **Chapter Query Profile**: For answering chapter questions
- **Timeline Fill Profile**: For generating retrieval queries (static mode)
- **Agentic Timeline Fill Profile**: For tool-based retrieval (agentic mode)
- **Arc Analyzer Profile**: For detecting story arcs
- **Lore Management Profile**: For lorebook editing
- **Max Requests per Minute**: Rate limiting to avoid API throttling
- **Max Chapters per Query**: Limit how many chapters can be queried at once (also affects agentic mode)
- **Max Timeline Fill Queries**: Limit queries per Timeline Fill operation (static mode only)

### Prompts

Each workflow type has configurable system and user prompts with macro support.

### Chapter Settings

- **Hide Summarized Messages**: Automatically hide messages after summarizing
- **Add chunk summaries**: Include individual chunk summaries as comments (for long chapters)

### Inject at Depth

- **Enable Timeline Injection**: Toggle automatic timeline injection
- **Injection Depth**: Position in message history (0 = end)
- **Injection Role**: System, User, or Assistant
- **Injection Prompt Template**: Customizable template with macro support

## Version History

| Version | Features |
|---------|----------|
| v1.0 | Initial release with tool calling for chapter queries |
| v1.1 | Added presets for summarization and query configurations |
| v1.2 | Added Arc Analyzer for automatic chapter endpoint detection |
| v1.3 | Added Timeline Fill for non-tool based memory retrieval |
| v1.4 | Fixed timeline responses, added master import/export |
| v1.5 | Added Lore Management Mode for autonomous lorebook editing |
| v1.6 | Arc Analyzer revamp, added modifiable chapter summaries |
| v1.7 | Updated default prompts |
| v1.8 | Usability update: tutorial mode, timeline-fill buttons, inject at depth, progress bar |
| v1.9 | Query limits for chapters per query and timeline fill queries, Spanish localization |
| v2.0 | **Agentic Timeline Fill**: Advanced tool-based retrieval mode with dynamic chapter querying and lorebook access |
| v2.5 | **Auto-Summarize**: Automatic chapter creation at message thresholds. **Loading Screen**: Immersive fullscreen experience with ambient music/backgrounds and fun facts. **Mini-Games**: Snake, Breakout, and Tetris playable during loading |

## Support

Feel free to open issues or PRs directly on GitHub, although no promises on timely resolution.

There is also a thread in the official SillyTavern Discord you're welcome to comment in!
